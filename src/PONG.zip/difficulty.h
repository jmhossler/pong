void difficulty(int *);
