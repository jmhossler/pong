#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <curses.h>
#include "difficulty.h"

//int
//main(){
//    int i=12,c;
//
//    initscr();
//    difficulty(&i);
//    endwin();
//    
//    for(c=0; c < i; ++c){
//        printf("%d\n",i);
//    }
//
//    return 0;
//}

void
difficulty(int *value){
    int i;
    char *question = "How difficult do you want this epic game to be?\n";
    char *opt = "0 for easy, 1 for medium, 2 for hard, 3 for very hard, 4 for dragon-master\n";
    clear();

    for(i = 0; i < LINES / 2 - 2; ++i){
        printw("\n");
    }

    for(i= 0; i < COLS / 2 - (int) strlen(question) / 2; ++i){
        printw(" ");
    }

    printw("%s",question);

    for(i= 0; i < COLS / 2 - (int) strlen(opt) / 2; ++i){
        printw(" ");
    }

    printw("%s",opt);
    for(i = 0; i < COLS / 2; ++i){
        printw(" ");
    }
    refresh();

    int ch = getch();
    printw("%d\n",ch);
    if(!(ch == 49 || ch == 48 || ch == 50 || ch == 51 || ch == 52)){
        difficulty(value);
    }
    else{
        *value = ch;
    }
}
