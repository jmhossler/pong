#include "paddles.h"

char **buffer(Paddle *, Paddle *, Ball *);
void paintBuffer(char **);
char *join(const char*, const char*);
