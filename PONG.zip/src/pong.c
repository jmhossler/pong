#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curses.h>
#include <math.h>
#include <unistd.h>
#include "difficulty.h"
#include "screen.h"

int
main(int argc, char **argv){
    int bestOutOf = atoi(argv[argc - 1]);
    initscr();
    cbreak();
    keypad(stdscr, TRUE);
    int i = 0;
    //difficulty(&i);

    Ball *ball = malloc(sizeof(Ball));
    ball->x = COLS / 2 - 2;
    ball->y = LINES / 2 - 1;
    ball->dx = 1;
    ball->dy = 1;

    Paddle *hum = malloc(sizeof(Paddle));
    hum->size = (int) pow((double) 2, (double) 4);
    hum->x = 2;
    hum->y = LINES / 2 - hum->size / 2;
    hum->dy = 0;

    Paddle *comp = malloc(sizeof(Paddle));
    comp->size = (int) pow((double) 2, (double) 0);
    comp->x = COLS - 3;
    comp->y = LINES / 2 - comp->size / 2;
    comp->dy = 0;
    comp->size = 14;

    char **array = buffer(hum, comp, ball);

    int test1 = 0;
    int test2 = 0;
    int testpad = 0;
    int testh = 0;
    int testc = 0;

    while(1){
        clear();
        paintBuffer(array);
        refresh();
        
        if(ball->y + 2 >= comp->y && ball->y <= comp->y + comp->size){
            if(ball->x + 5 == comp->x){
                test1 = 1;
                testc = 1;
            }
        }
        if(ball->y + 2 >= hum->y && ball->y <= hum->y + hum->size){
            if(ball->x == hum->x + 2){
                test1 = 0;
                testh = 0;
            }
        }

        if(ball->x + 4 == COLS){
            --bestOutOf;
            test1 = 1;
        }
        else if(ball->x == 1){
            --bestOutOf;
            test1 = 0;
        }

        if(ball->y + 4 >= LINES){
            test2 = 1;
        }
        if(ball->y == 1){
            test2 = 0;
        }

        if(ball->y - 2 >= comp->y && ball->y == comp->y + comp->size - 1){
            testpad = 2;
        }
        else if(comp->y < ball->y){
            if(!(comp->y + comp->size + 1 == LINES)){
                testpad = 0;
            }
            else{
                testpad = 2;
            }
        }
        else if(comp->y > ball->y){
            if(!(comp->y == 1)){
                testpad = 1;
            }
            else{
                testpad = 2;
            }
        }

        switch(test1){
            case 0:
                changeDX(abs(ball->dx),ball);
                break;
            case 1:
                changeDX(abs(ball->dx) * -1,ball);
                break;
        }

        switch(test2){
            case 0:
                changeDY(abs(ball->dy),ball);
                break;
            case 1:
                changeDY(abs(ball->dy) * -1,ball);
                break;
        }

        /*switch(testh){
            case 0:
                break;
            case 1:
                changeDX(ball->dx + hum->dy,ball);
                break;
        }

        switch(testc){
            case 0:
                break;
            case 1:
                changeDX(ball->dx + comp->dy,ball);
                break;
        }*/

        switch(testpad){
            case 0:
                changePaddle(1,comp);
                break;
            case 1:
                changePaddle(-1,comp);
                break;
            case 2:
                changePaddle(0,comp);
        } 

        timeout(1);
        int ch = getch();
        if(ch == KEY_DOWN){
            if(!(hum->y + hum->size + 1 >= LINES)){
                changePaddle(2,hum);
            }
            else{
                changePaddle(0,hum);
            }
        }
        else if(ch == KEY_UP){
            if(!(hum->y <= 1)){
                changePaddle(-2,hum);
            }
            else{
                changePaddle(0,hum);
            }
        }
        else if(ch == 27 || bestOutOf == -1){
            endwin();
            return 0;
        }
        else{
            changePaddle(0,hum);
        }

        comp->x = COLS -3;
        movePaddle(hum);
        movePaddle(comp);
        moveBall(ball);
        free(array);
        array = buffer(hum,comp,ball);

        usleep(25000);
    }
}
